# Shopify Taxonomy Product Classifier

A Django + DRF prototype that imports a product catalogue (10,000+ rows), matches
each product to the [Shopify Product Taxonomy](https://github.com/Shopify/product-taxonomy),
detects category attributes/values, scores its own confidence, and exposes a
review UI + JSON API to approve or correct results.

Built and tested against the supplied `Product_List.xlsx` (4,999 Modway
furniture products). Full run on all 4,999 rows: **~52 seconds, 0 errors**,
~96 products/sec — comfortably meets the 10,000+ product requirement
(≈ 1.5–2 minutes for 10k on similar hardware).

## 1. What's included, mapped to the requirements

| # | Requirement | Where |
|---|---|---|
| 1 | Import product list | `classifier/management/commands/import_products.py` |
| 2 | Identify Shopify taxonomy category | `classifier/engine.py` (`classify_product`) — TF-IDF match against the real taxonomy |
| 3 | Detect category attributes & values | `engine.py` `TaxonomyIndex.find_values()` against Shopify's controlled value lists |
| 4 | Works with & without images | `image_engine.py` is optional/pluggable; pipeline runs text-only when no image model is available |
| 5 | Handles missing description/info | Text fields default to `""`; missing fields lower confidence and add a `review_reasons` entry, never crash |
| 6 | Uses title, description, type, brand, image | `build_product_text()` combines all of these; images via `--use-images` |
| 7 | Confidence score per classification | `Classification.confidence` (0–1) |
| 8 | Alternative suggestions when confidence is low | `Classification.alternatives` (top 3 runner-up categories) |
| 9 | Flags products needing manual review | `Classification.status` = `needs_review` + `review_reasons` |
| 10 | Batch processing, 10,000+ products | `classify_products` command processes in chunks (`--batch-size`), see benchmark above |
| 11 | Never stops on bad data/images/errors | Every row/product is wrapped in `try/except`; failures land in `ProcessingError` and the product still gets a (flagged) result |
| 12 | Simple UI/API to view & approve/update | DRF API under `/api/...` + single-page review UI at `/` |

## 2. Architecture

```
Product_List.xlsx
       │  import_products (management command)
       ▼
   Product  ───────────────┐
       │                   │  classify_products (batch command)
       ▼                   ▼
  engine.py: TF-IDF match  image_engine.py (optional, CLIP zero-shot)
  against bundled Shopify        │
  taxonomy (14,606 categories)   │
       │                         │
       └──────────┬──────────────┘
                   ▼
             Classification
        (category, confidence, alternatives,
         attributes, status, review_reasons)
                   │
       ┌───────────┴───────────┐
       ▼                       ▼
   DRF JSON API          Review UI (/)
   /api/products/        filter, inline edit,
   /api/.../classification/  approve/reject
```

### Why TF-IDF instead of calling an LLM/embeddings API per product
This prototype had to run fully offline (no LLM API access in the build
environment), so category matching uses a classic, dependency-light approach:
a TF-IDF vector space built once over all ~14,600 taxonomy category names/paths,
then every product is a single vector transform + cosine similarity lookup.
This is fast enough for 10k+ products on a laptop and needs no external API
calls or GPU. **In a production deployment with LLM/embedding API access**, swap
`TaxonomyIndex.search()` for an embedding-similarity or LLM-classification call
— the rest of the pipeline (confidence handling, review queue, attribute
extraction, API, UI) is unchanged. This swap point is intentionally isolated
to make that upgrade a contained change.

### Taxonomy data
`classifier/data/taxonomy_categories.json` and `attribute_values.json` are
compacted, deduplicated exports of Shopify's official taxonomy
(`Shopify/product-taxonomy`, `dist/en/`), so the app never depends on network
access at classification time. To refresh them against a newer taxonomy
release, re-run the extraction shown in `docs/refresh_taxonomy.md`.

### Confidence scoring
Raw TF-IDF cosine similarity is linearly rescaled (`CALIBRATION_SCALE` in
`engine.py`) so a near-certain match reads as ~90%+ rather than ~50%. Title
text is weighted separately from the full description (a short, precise title
match should outweigh being buried in a long paragraph), and the seller's own
category/sub-category columns act as a *tie-breaker* bonus (not the dominant
signal) between identically-named categories in different taxonomy branches,
e.g. indoor vs. outdoor "Dining Tables".

Products are auto-approved (`CONFIDENCE_AUTO_APPROVE`, default 0.80),
otherwise routed to manual review (`CONFIDENCE_REVIEW_BELOW`, default 0.55) —
adjust both in `taxoclassify/settings.py` to taste.

### Robustness (requirement #11)
- Import: each spreadsheet row is wrapped individually; a bad row is logged to
  `ProcessingError` and the import continues.
- Classification: each product is wrapped individually; a failure still writes
  a `Classification` row with `status="error"` (so it surfaces in the review
  queue) instead of disappearing.
- Images: a broken/missing image URL is caught per-image; the product simply
  falls back to text-only scoring.
- Everything above is queryable via the admin at `/admin/` (`ProcessingError`
  model) or via `/api/stats/`.

## 3. Running it

```bash
pip install -r requirements.txt
python manage.py migrate
python manage.py createsuperuser        # optional, for /admin/

# 1. Import the catalogue
python manage.py import_products /path/to/Product_List.xlsx

# 2. Classify (add --use-images to also try image-based signal, if you've
#    installed torch/open_clip_torch/pillow and have network access to a model hub)
python manage.py classify_products

# 3. Run the app
python manage.py runserver
```

Then open **http://localhost:8000/** for the review UI, or use the API directly:

- `GET /api/stats/` — dashboard counts
- `GET /api/products/?status=needs_review&max_confidence=0.5&q=chair` — filterable, paginated list
- `GET /api/products/<id>/` — full detail
- `PATCH /api/products/<id>/classification/` — approve / reject / correct
  `{"status": "approved"}` or `{"category_name": "Armchairs", "status": "approved"}`
- `GET /api/categories/search/?q=sofa` — taxonomy autocomplete (used by the UI's inline editor)
- `GET /api/import-batches/` — import history

Re-running `classify_products` is safe — it skips already-classified products
unless you pass `--reclassify-all`. Useful flags:
`--batch-size 500`, `--limit 100` (smoke-test on a subset),
`--import-batch <id>` (only classify one import run).

## 4. Switching to MariaDB (the specified production backend)

The prototype defaults to SQLite so it runs with zero setup. To use MariaDB:

```bash
pip install mysqlclient
export USE_MARIADB=1
export DB_NAME=taxoclassify DB_USER=taxoclassify DB_PASSWORD=... DB_HOST=127.0.0.1
python manage.py migrate
```

No code changes needed — see `taxoclassify/settings.py`.

## 5. Scaling beyond this prototype

- **Async/queue**: wrap `classify_product()` in a Celery task and dispatch
  batches from `classify_products` (or a Django signal on import) for
  horizontal scaling and retries beyond a single process.
- **Real image classification**: `image_engine.py` is written against
  `open_clip` zero-shot classification but requires network access to
  download model weights once; install `torch`, `open_clip_torch`, `pillow`
  and pass `--use-images`. It's isolated so the rest of the app is unaffected
  either way.
- **Better category matching at scale**: swap the TF-IDF index in
  `engine.py` for sentence-embedding similarity (e.g. a local
  `sentence-transformers` model) or an LLM classification call per product —
  the confidence/review/API/UI layers don't need to change.
- **Human-in-the-loop feedback**: reviewer corrections are already captured
  (`Classification.status`, `reviewer_notes`); a natural next step is logging
  corrected (product → category) pairs and periodically fine-tuning/re-weighting
  the matcher against them.

## 6. Known limitations of this prototype

- Category matching is lexical (TF-IDF), not semantic — it can miss
  synonyms the taxonomy doesn't share words with (e.g. a very
  creatively-named product with no descriptive words at all). Flagged
  products should be reviewed with this in mind, and the "review below"
  threshold is intentionally conservative (~55% of the tested catalogue was
  flagged for review) rather than risk false confidence.
- Image classification is implemented but disabled in fully offline
  environments (no model-hub network access) — this is by design (requirement
  #4: must still work without images) but means the demo above is text-only.
- Attribute-value extraction is dictionary/substring matching against
  Shopify's controlled vocabularies; it will not infer a value that isn't
  phrased close to the taxonomy's own wording.
