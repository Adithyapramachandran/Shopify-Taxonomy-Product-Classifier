import traceback
from pathlib import Path

import pandas as pd
from django.core.management.base import BaseCommand
from django.utils import timezone

from classifier.models import ImportBatch, Product, ProcessingError

# Maps our Product model fields -> possible source spreadsheet column names.
# First matching column (case-insensitive, whitespace-trimmed) wins. This
# makes the importer resilient to minor header variations across catalogues.
COLUMN_MAP = {
    "sku": ["Product Number", "SKU", "Product SKU"],
    "model_number": ["Model Number"],
    "title": ["Product Name", "Title", "Product Title"],
    "description": ["Product Description", "Description"],
    "bullets": ["Bullets", "Features"],
    "brand": ["Brand", "Manufacturer"],
    "source_category": ["Product Category", "Category"],
    "source_sub_category": ["Product Sub Category", "Sub Category"],
    "collection_name": ["Collection Name"],
    "color": ["Product Color", "Color"],
    "materials": ["Materials", "Material"],
    "dimensions": ["Product Dimensions", "Dimensions"],
    "weight": ["Product Weight", "Weight"],
    "country_of_origin": ["Country Of Origin", "Country of Origin"],
    "product_url": ["Product URL", "URL"],
}

IMAGE_COLUMN_PREFIXES = ["Image "]


def _clean(value):
    if value is None:
        return ""
    if isinstance(value, float) and pd.isna(value):
        return ""
    text = str(value).strip()
    if text.lower() == "nan":
        return ""
    return text.replace("_x000D_", " ").replace("\\n", " ")


def _resolve_columns(df_columns):
    normalized = {c.strip().lower(): c for c in df_columns}
    resolved = {}
    for field, candidates in COLUMN_MAP.items():
        for cand in candidates:
            key = cand.strip().lower()
            if key in normalized:
                resolved[field] = normalized[key]
                break
    image_cols = [c for c in df_columns if any(c.strip().lower().startswith(p.lower()) for p in IMAGE_COLUMN_PREFIXES)]
    return resolved, image_cols


class Command(BaseCommand):
    help = "Import a product catalogue (.xlsx/.csv) into the database, ready for classification."

    def add_arguments(self, parser):
        parser.add_argument("filepath", type=str, help="Path to the .xlsx or .csv product list")
        parser.add_argument("--sheet", type=str, default=0, help="Sheet name/index for .xlsx files")

    def handle(self, *args, **options):
        filepath = Path(options["filepath"])
        if not filepath.exists():
            self.stderr.write(self.style.ERROR(f"File not found: {filepath}"))
            return

        if filepath.suffix.lower() in (".xlsx", ".xls"):
            df = pd.read_excel(filepath, sheet_name=options["sheet"])
        else:
            df = pd.read_csv(filepath)

        batch = ImportBatch.objects.create(
            source_filename=filepath.name, status="running", total_rows=len(df)
        )
        self.stdout.write(f"Importing {len(df)} rows from {filepath.name} (batch #{batch.id})...")

        resolved, image_cols = _resolve_columns(df.columns)
        missing = [f for f in ("sku", "title") if f not in resolved]
        if missing:
            self.stderr.write(self.style.WARNING(
                f"Could not confidently locate columns for: {missing}. "
                f"Falling back to positional guesses where possible."
            ))

        imported, failed = 0, 0
        for i, row in df.iterrows():
            row_ref = f"row {i + 2}"  # +2 = header row + 1-indexing, matches spreadsheet line numbers
            try:
                data = {field: _clean(row.get(col)) for field, col in resolved.items()}
                sku = data.get("sku") or f"NO-SKU-ROW-{i + 2}"

                images = []
                for col in image_cols:
                    val = _clean(row.get(col))
                    if val:
                        images.append(val)

                raw_data = {col: _clean(row.get(col)) for col in df.columns if col not in resolved.values()}

                quality_notes = []
                if not data.get("description"):
                    quality_notes.append("missing_description")
                if not images:
                    quality_notes.append("missing_images")
                if not data.get("title"):
                    quality_notes.append("missing_title")

                Product.objects.update_or_create(
                    sku=sku,
                    defaults=dict(
                        import_batch=batch,
                        model_number=data.get("model_number", ""),
                        title=data.get("title", ""),
                        description=data.get("description", ""),
                        bullets=data.get("bullets", ""),
                        brand=data.get("brand", ""),
                        source_category=data.get("source_category", ""),
                        source_sub_category=data.get("source_sub_category", ""),
                        collection_name=data.get("collection_name", ""),
                        color=data.get("color", ""),
                        materials=data.get("materials", ""),
                        dimensions=data.get("dimensions", ""),
                        weight=data.get("weight", ""),
                        country_of_origin=data.get("country_of_origin", ""),
                        product_url=data.get("product_url", ""),
                        image_urls=images,
                        raw_data=raw_data,
                        has_description=bool(data.get("description")),
                        has_image=bool(images),
                        data_quality_notes=quality_notes,
                    ),
                )
                imported += 1
            except Exception as e:
                failed += 1
                ProcessingError.objects.create(
                    import_batch=batch, stage="import", row_reference=row_ref,
                    message=str(e), traceback=traceback.format_exc(),
                )
                continue  # never let one bad row stop the import (requirement #11)

            if imported % 500 == 0:
                self.stdout.write(f"  ...{imported} rows imported")

        batch.imported_rows = imported
        batch.failed_rows = failed
        batch.status = "completed"
        batch.finished_at = timezone.now()
        batch.save()

        self.stdout.write(self.style.SUCCESS(
            f"Import finished: {imported} imported, {failed} failed. Batch #{batch.id}."
        ))
