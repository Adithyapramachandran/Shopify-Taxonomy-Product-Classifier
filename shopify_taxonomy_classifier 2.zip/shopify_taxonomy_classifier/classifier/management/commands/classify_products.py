import time
import traceback

from django.conf import settings
from django.core.management.base import BaseCommand
from django.db import transaction

from classifier.engine import classify_product, ENGINE_VERSION
from classifier.models import Classification, Product, ProcessingError


class Command(BaseCommand):
    help = (
        "Run the taxonomy classification engine over products in batches. "
        "Safe to re-run: already-classified products are skipped unless --reclassify-all is given."
    )

    def add_arguments(self, parser):
        parser.add_argument("--batch-size", type=int, default=200)
        parser.add_argument("--limit", type=int, default=None, help="Only process this many products (for testing).")
        parser.add_argument("--reclassify-all", action="store_true", help="Re-run even products that already have a classification.")
        parser.add_argument("--import-batch", type=int, default=None, help="Only classify products from this ImportBatch id.")
        parser.add_argument("--use-images", action="store_true", help="Attempt image-based classification signal (requires network + model).")

    def handle(self, *args, **options):
        qs = Product.objects.all().order_by("id")
        if options["import_batch"]:
            qs = qs.filter(import_batch_id=options["import_batch"])
        if not options["reclassify_all"]:
            qs = qs.filter(classification__isnull=True)
        if options["limit"]:
            qs = qs[: options["limit"]]

        total = qs.count()
        self.stdout.write(f"Classifying {total} products (batch size {options['batch_size']})...")

        batch_size = options["batch_size"]
        processed = 0
        errors = 0
        t0 = time.time()

        ids = list(qs.values_list("id", flat=True))
        for start in range(0, len(ids), batch_size):
            chunk_ids = ids[start:start + batch_size]
            chunk = Product.objects.filter(id__in=chunk_ids)
            with transaction.atomic():
                for product in chunk:
                    try:
                        image_bytes = None
                        if options["use_images"] and product.image_urls:
                            image_bytes = self._fetch_images(product.image_urls[:3])

                        outcome = classify_product(product, image_bytes_list=image_bytes)
                        self._save_outcome(product, outcome)
                        processed += 1
                    except Exception as e:
                        errors += 1
                        ProcessingError.objects.create(
                            product=product, stage="text_classification",
                            row_reference=product.sku,
                            message=str(e), traceback=traceback.format_exc(),
                        )
                        # Still write a minimal error classification so the
                        # product is visible in the review queue rather than
                        # silently disappearing (requirement #11).
                        Classification.objects.update_or_create(
                            product=product,
                            defaults=dict(
                                status="error",
                                review_reasons=[f"Classification error: {e}"],
                                engine_version=ENGINE_VERSION,
                            ),
                        )
                        continue

            elapsed = time.time() - t0
            rate = processed / elapsed if elapsed > 0 else 0
            self.stdout.write(f"  ...{processed}/{total} processed ({rate:.1f}/sec, {errors} errors)")

        self.stdout.write(self.style.SUCCESS(
            f"Done. Processed {processed} products, {errors} errors, in {time.time() - t0:.1f}s."
        ))

    def _fetch_images(self, urls):
        import requests
        out = []
        for url in urls:
            try:
                resp = requests.get(url, timeout=5)
                if resp.status_code == 200:
                    out.append(resp.content)
            except Exception:
                continue  # a missing/broken image must never stop the batch (requirement #11)
        return out

    def _save_outcome(self, product, outcome):
        if outcome.category is None:
            status = "needs_review"
        else:
            confidence = outcome.text_confidence
            if outcome.used_image and outcome.image_confidence is not None:
                confidence = min(1.0, 0.7 * outcome.text_confidence + 0.3 * outcome.image_confidence)
            if outcome.review_reasons and confidence < settings.CONFIDENCE_AUTO_APPROVE:
                status = "needs_review"
            elif confidence >= settings.CONFIDENCE_AUTO_APPROVE:
                status = "auto_approved"
            else:
                status = "pending"

        confidence = 0.0
        if outcome.category is not None:
            confidence = outcome.text_confidence
            if outcome.used_image and outcome.image_confidence is not None:
                confidence = min(1.0, 0.7 * outcome.text_confidence + 0.3 * outcome.image_confidence)

        Classification.objects.update_or_create(
            product=product,
            defaults=dict(
                category_id=outcome.category.category_id if outcome.category else "",
                category_name=outcome.category.name if outcome.category else "",
                category_full_name=outcome.category.full_name if outcome.category else "",
                confidence=confidence,
                text_confidence=outcome.text_confidence,
                image_confidence=outcome.image_confidence,
                used_image=outcome.used_image,
                alternatives=outcome.alternatives,
                attributes=outcome.attributes,
                status=status,
                review_reasons=outcome.review_reasons,
                engine_version=ENGINE_VERSION,
            ),
        )
