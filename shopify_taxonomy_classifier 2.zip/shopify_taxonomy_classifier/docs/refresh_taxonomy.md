# Refreshing the bundled Shopify taxonomy data

The app ships a compacted copy of Shopify's official taxonomy under
`classifier/data/`, so it needs no network access at classification time.
To refresh it against a newer taxonomy release:

```bash
git clone --depth 1 https://github.com/Shopify/product-taxonomy.git
cd product-taxonomy/dist/en

python3 - << 'PY'
import json

cats = json.load(open('categories.json'))
all_categories = []
for v in cats['verticals']:
    for c in v['categories']:
        all_categories.append({
            "id": c["id"], "name": c["name"], "full_name": c["full_name"],
            "level": c["level"], "parent_id": c["parent_id"], "vertical": v["name"],
            "attributes": [{"handle": a["handle"], "name": a["name"]} for a in c.get("attributes", [])],
        })
json.dump(all_categories, open('taxonomy_categories.json', 'w'))

attr_values = {}
with open('attribute_values.txt', encoding='utf-8') as f:
    for line in f:
        line = line.strip()
        if not line or line.startswith('#'):
            continue
        try:
            _, rest = line.split(' : ', 1)
            value_name, attr_name = rest.rsplit(' [', 1)
            attr_values.setdefault(attr_name.rstrip(']'), []).append(value_name.strip())
        except ValueError:
            continue
json.dump(attr_values, open('attribute_values.json', 'w'))
PY

cp taxonomy_categories.json  <project>/classifier/data/taxonomy_categories.json
cp attribute_values.json     <project>/classifier/data/attribute_values.json
rm -f <project>/classifier/data/taxonomy_model.pkl   # force the TF-IDF index to rebuild
```
